// script.js

document.addEventListener('DOMContentLoaded', () => {
    const newsList = document.getElementById('news-list');
    const commentList = document.getElementById('comment-list');

    // Example news data
    const newsItems = [
        { title: 'Breaking News: Market Hits Record High', link: '#', category: 'tech' },
        { title: 'Sports: Local Team Wins Championship', link: '#', category: 'sports' },
        { title: 'Politics: Debate Sparks Controversy', link: '#', category: 'politics' },
        { title: 'Entertainment: Movie Breaks Box Office Records', link: '#', category: 'entertainment' }
    ];

    const renderNews = (category = null) => {
        newsList.innerHTML = '';
        newsItems
            .filter(item => !category || item.category === category)
            .forEach(item => {
                const li = document.createElement('li');
                const a = document.createElement('a');
                a.href = item.link;
                a.textContent = item.title;
                li.appendChild(a);
                newsList.appendChild(li);
            });
    };

    const postComment = () => {
        const commentBox = document.getElementById('comment-box');
        if (commentBox.value.trim()) {
            const li = document.createElement('li');
            li.textContent = commentBox.value;
            commentList.appendChild(li);
            commentBox.value = '';
        }
    };

    // Event listeners
    document.getElementById('post-comment-btn').addEventListener('click', postComment);

    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', () => renderNews(btn.dataset.category));
    });

    renderNews(); // Initial render
});
